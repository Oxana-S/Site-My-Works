<div class="articles">
    <?php require_once 'ajax/articles_show.php' ?>

</div>