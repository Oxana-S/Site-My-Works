<footer>Все права защищены</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="js/chat_send.js"></script>
<script src="js/chat_show_add.js"></script>